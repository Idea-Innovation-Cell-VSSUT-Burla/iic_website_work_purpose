var config = {
apiKey: "AIzaSyAI0lETUk8sDpp-yeG9H6csV34x5umKXgc",
  authDomain: "iicinduction2021.firebaseapp.com",
databaseURL: "https://iicinduction2021-default-rtdb.firebaseio.com",
  projectId: "iicinduction2021",
  storageBucket: "iicinduction2021.appspot.com",
  messagingSenderId: "729161589904",
  appId: "1:729161589904:web:383e72d3bc6f7b70c36415",
  measurementId: "G-JZBCHFDY23"
 
  };
     firebase.initializeApp(config);
    console.log(firebase);